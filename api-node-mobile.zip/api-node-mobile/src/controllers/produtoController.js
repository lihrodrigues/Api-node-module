const express = require('express');
const produtoService = require('../services/produtoService');
const authenticateToken = require('../middleware/auth');
const router = express.Router();

router.get('/', async (req, res) =>{
    try{
        const produto = await produtoService.getproduto();
        res.json(produto);
    }
    catch(error){
        res.status(400).json({error: error.message});
    }
})

router.post('/',authenticateToken, async(req,res) =>{
    const { nome,descricao, preco, categoria } = req.body;

try{
    const produto = await produtoService.register(nome,descricao, preco, categoria);
    res.status(201).json(produto);
} catch (error){
    res.status(400).json({ error: error.message})
}
});

module.exports = router;